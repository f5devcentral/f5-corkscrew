/*jslint sub:true, white: true */
var interesting_attrs = {};
interesting_attrs["?import"] =
{
    re: /\b(implementation)\b/ig,
    implementation:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["a"] =
{
    re: /\b(href|ping|xlink:href)\b/ig,
    href:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    ping:
    {
        hint: 'H',
        separator: ' ',
        rewrite_content: rewrite_uri
    },
    "xlink:href":
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["applet"] =
{
    re: /\b(archive|codebase)\b/ig,
    archive:
    {
        hint: 'V',
        separator: ',',
        rewrite_content: rewrite_uri
    },
    codebase:
    {
        hint: '',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["area"] =
{
    re: /\b(href|ping)\b/ig,
    href:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    ping:
    {
        hint: 'H',
        separator: ' ',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["audio"] =
{
    re: /\b(src)\b/ig,
    src:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["base"] =
{
    re: /\b(href)\b/ig,
    href:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["bgsound"] =
{
    re: /\b(src)\b/ig,
    src:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["blockquote"] =
{
    re: /\b(cite)\b/ig,
    cite:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["body"] =
{
    re: /\b(background)\b/ig,
    background:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["button"] =
{
    re: /\b(formaction)\b/ig,
    formaction:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["command"] =
{
    re: /\b(icon)\b/ig,
    icon:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["del"] =
{
    re: /\b(cite)\b/ig,
    cite:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["div"] =
{
    re: /\b(helplink)\b/ig,
    helplink:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["embed"] =
{
    re: /\b(archive|codebase|java_codebase|pluginspage|src)\b/ig,
    archive:
    {
        hint: 'V',
        separator: ',',
        rewrite_content: rewrite_uri
    },
    codebase:
    {
        hint: '',
        rewrite_content: rewrite_uri
    },
    java_codebase:
    {
        hint: '',
        rewrite_content: rewrite_uri
    },
    pluginspage:
    {
        hint: '',
        rewrite_content: rewrite_uri
    },
    src:
    {
        hint: '',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["feImage"] =
{
    re: /\b(style|xlink:href)\b/ig,
    style:
    {
        hint: 'C',
        rewrite_content: rewrite_css
    },
    "xlink:href":
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["form"] =
{
    re: /\b(action)\b/ig,
    action:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["frame"] =
{
    re: /\b(longdesc|security|src)\b/ig,
    dependencies:
    {
        a: {
            d_src: "security", d_dst: "src", d_value: "restricted",
            src:
            {
                rewrite_content: rewrite_uri_sid
            }
        }
    },
    longdesc:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    src:
    {
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["head"] =
{
    re: /\b(profile)\b/ig,
    profile:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["html"] =
{
    re: /\b(manifest)\b/ig,
    manifest:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["iframe"] =
{
    re: /\b(longdesc|security|src)\b/ig,
    dependencies:
    {
        a: {
            d_src: "security", d_dst: "src", d_value: "restricted",
            src:
            {
                rewrite_content: rewrite_uri_sid
            }
        }
    },
    longdesc:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    src:
    {
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["ilayer"] =
{
    re: /\b(background)\b/ig,
    background:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["image"] =
{
    re: /\b(dynsrc|longdesc|lowsrc|src|usemap|xlink:href)\b/ig,
    dynsrc:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    },
    longdesc:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    lowsrc:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    },
    src:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    },
    usemap:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    "xlink:href":
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["img"] =
{
    re: /\b(dynsrc|longdesc|lowsrc|src|usemap)\b/ig,
    dynsrc:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    },
    longdesc:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    lowsrc:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    },
    src:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    },
    usemap:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["input"] =
{
    re: /\b(formaction|href|name|posturl|src|usemap|value)\b/ig,
    dependencies:
    {
        a:
        {
            d_src: "name", d_dst: "value", d_value: "listviewurl", d_hint: '-',
            value:
            {
                rewrite_content: rewrite_uri
            }
        },
        b:
        {
            d_src: "name", d_dst: "value", d_value: "posturl", d_hint: '-',
            value:
            {
                rewrite_content: rewrite_escaped_uri
            }
        },
        c:
        {
            d_src: "name", d_dst: "value", d_value: "confirmation-url", d_hint: '-',
            value:
            {
                rewrite_content: rewrite_uri
            }
        }
    },
    formaction:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    href:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    },
    posturl:
    {
        rewrite_content: rewrite_uri
    },
    src:
    {
        rewrite_content: rewrite_uri
    },
    usemap:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["ins"] =
{
    re: /\b(cite)\b/ig,
    cite:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["isindex"] =
{
    re: /\b(action)\b/ig,
    action:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["layer"] =
{
    re: /\b(background|src)\b/ig,
    background:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    },
    src:
    {
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["link"] =
{
    re: /\b(href|rel)\b/ig,
    dependencies:
    {
        a: { d_src: "rel", d_dst: "href", d_value: "stylesheet", d_hint: 'C' },
        b: { d_src: "rel", d_dst: "href", d_value: "alternate stylesheet", d_hint: 'C' }
    },
    href:
    {
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["map"] =
{
    re: /\b(href)\b/ig,
    href:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["meta"] =
{
    re: /\b(content|http-equiv)\b/ig,
    dependencies:
    {
        a:
        {
            d_src: "http-equiv", d_dst: "content", d_hint: '-', d_value: "refresh",
            content:
            {
                rewrite_content: rewrite_refresh
            }
        },
        b:
        {
            d_src: "http-equiv", d_dst: "content", d_hint: '-', d_value: "location",
            content:
            {
                rewrite_content: rewrite_location
            }
        },
        c:
        {
            d_src: "http-equiv", d_dst: "content", d_hint: '-', d_value: "set-cookie",
            content:
            {
                rewrite_content: rewrite_cookie
            }
        }
    }
};
interesting_attrs["object"] =
{
    re: /\b(archive|classid|codebase|data|usemap)\b/ig,
    archive:
    {
        separator: ' ',
        hint: 'V',
        rewrite_content: rewrite_uri
    },
    classid:
    {
        rewrite_content: rewrite_uri
    },
    codebase:
    {
        rewrite_content: rewrite_uri
    },
    data:
    {
        hint: '-',
        rewrite_content: rewrite_uri
    },
    usemap:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["param"] =
{
    re: /\b(name|value)\b/ig,
    dependencies:
    {
        a: { d_src: "name", d_dst: "value", d_hint: 'F', d_value: "movie", value: { rewrite_content: rewrite_uri } },
        b: { d_src: "name", d_dst: "value", d_hint: 'F', d_value: "src", value: { rewrite_content: rewrite_uri } },
        c: { d_src: "name", d_dst: "value", d_hint: '-', d_value: "general_url", value: { rewrite_content: rewrite_uri } },
        d: { d_src: "name", d_dst: "value", d_hint: '-', d_value: "mail_maildbpath", value: { rewrite_content: rewrite_uri } },
        e: { d_src: "name", d_dst: "value", d_hint: '-', d_value: "listweb", value: { rewrite_content: rewrite_uri } },
        f: { d_src: "name", d_dst: "value", d_hint: '-', d_value: "app", value: { rewrite_content: rewrite_uri } },
        g: { d_src: "name", d_dst: "value", d_hint: 'V', d_value: "cabbase", value: { rewrite_content: rewrite_uri } },
        h: { d_src: "name", d_dst: "value", d_hint: 'I', d_value: "source", value: { rewrite_content: rewrite_uri } },
        i: { d_src: "name", d_dst: "value", d_hint: 'V', d_value: "archive", value: { rewrite_content: rewrite_uri } },
        j: { d_src: "name", d_dst: "value", d_hint: '-', d_value: "codebase", value: { rewrite_content: rewrite_uri } },
	k: { d_src: "name", d_dst: "value", d_hint: '-', d_value: "jnlp_href", value: { rewrite_content: rewrite_uri } },
	l: { d_src: "name", d_dst: "value", d_hint: '-', d_value: "path", value: { rewrite_content: rewrite_uri } }
    }
};
interesting_attrs["q"] =
{
    re: /\b(cite)\b/ig,
    cite:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["script"] =
{
    re: /\b(src|xlink:href)\b/ig,
    rewrite_content: rewrite_self,
    src:
    {
        rewrite_content: rewrite_uri
    },
    "xlink:href":
    {
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["source"] =
{
    re: /\b(src)\b/ig,
    src:
    {
        hint: 'H',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["style"] =
{
    re: /\b(src)\b/ig,
    rewrite_content: rewrite_css,
    src:
    {
        hint: 'C',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["table"] =
{
    re: /\b(background)\b/ig,
    background:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["td"] =
{
    re: /\b(background)\b/ig,
    background:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["textarea"] =
{
    rewrite_content: rewrite_self
};
interesting_attrs["th"] =
{
    re: /\b(background)\b/ig,
    background:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["title"] =
{
    rewrite_content: rewrite_self
};
interesting_attrs["track"] =
{
    re: /\b(src)\b/ig,
    src:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["use"] =
{
    re: /\b(xlink:href)\b/ig,
    "xlink:href":
    {
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["video"] =
{
    re: /\b(poster|src)\b/ig,
    poster:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    },
    src:
    {
        hint: 'I',
        rewrite_content: rewrite_uri
    }
};
interesting_attrs["xml"] =
{
    re: /\b(src)\b/ig,
    src:
    {
        hint: 'X',
        rewrite_content: rewrite_uri
    }
};
/*jslint sub:false, white: false */
