/*jslint sub:true, white: true */
var interesting_attrs = {};
interesting_attrs["script"] =
{
    rewrite_content: rewrite_self
};
interesting_attrs["textarea"] =
{
    rewrite_content: rewrite_self
};
interesting_attrs["title"] =
{
    rewrite_content: rewrite_self
};
/*jslint sub:false, white: false */
